<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Participants;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('participants', 'ParticipantsController@index');
Route::get('participants/{participants}', 'ParticipantsController@show');
Route::post('participants', 'ParticipantsController@store');
Route::put('participants/{participants}', 'ParticipantsController@update');
Route::delete('participants/{participants}', 'ParticipantsController@delete');