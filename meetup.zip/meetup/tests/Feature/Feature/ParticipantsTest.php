<?php

namespace Tests\Feature\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ParticipantsTest extends TestCase {

    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function testParticipantsRegistration() {
        $payload = [
            'name' => 'Suraj',
            'age' => 30,
            'dob' => '1990-07-07',
            'address' => 'Lokhandwala',
            'locality' => 'Kandivali',
            'profession' => 'Employed',
            'guests' => 2
        ];

        $this->json('post', '/api/participants', $payload)
                ->assertStatus(200);
    }

}
