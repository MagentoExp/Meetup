<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Participants;
use Validator;

/**
 * Run the migrations.
 * @author Suraj Mishra Doe <msooraz@gmail.com>
 * @return void
 */
class ParticipantsController extends Controller {

    /**
     * Show all Participants users.
     * @author Suraj Mishra Doe <msooraz@gmail.com>
     */
    public function index() {
        $participants = Participants::all();
        if (is_null($participants))
            return json_encode(array("message" => 'No Records Found to update'));
        return $participants;
    }

    /**
     * Store the Participants registration form details.
     * @author Suraj Mishra Doe <msooraz@gmail.com>
     */
    public function store(Request $request) {
        $response = array('response' => '', 'success' => false);
        $validator = Validator::make($request->all(), [
                    'name' => 'required|min:2|max:50',
                    'age' => 'required|numeric',
                    'dob' => 'before:5 years ago',
                    'address' => 'required|max:50',
                    'guests' => 'required|integer|between:0,2'], [
                    'name.required' => 'Name is required',
                    'name.min' => 'Name must be at least 2 characters.',
                    'name.max' => 'Name should not be greater than 50 characters.',
        ]);

        if ($validator->fails()) {
            $response['response'] = $validator->messages();
        } else {

            return Participants::create($request->all()) ? 'Success' : 'Failed';
        }
        return $response;
    }

    /**
     * Update the Participants Details.
     * @author Suraj Mishra Doe <msooraz@gmail.com>
     */
    public function update(Request $request, $participant) {
        $participantsOperation = Participants::find($participant);
        if (is_null($participantsOperation))
            return json_encode(array("message" => 'No Records Found to update'));
        return $participantsOperation->update($request->all()) ? "Success" : "Failed";
    }

}
