<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Model File.
 * @author Suraj Mishra Doe <msooraz@gmail.com>
 */
class Participants extends Model {

    protected $fillable = ['name', 'age', 'dob', 'profession', 'locality', 'guests', 'address'];

}
